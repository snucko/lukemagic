# Luke — Astro Site + RepoMirror (Styled)

- Astro + Tailwind (dark theme)
- PWA, RSS, sitemap, search index, ICS feed
- RepoMirror hooks ready (configure repos in `repomirror.config.json`)

## Dev
npm i
npm run dev

## Build/Deploy
Push to main: CI mirrors repos, builds, deploys to GitHub Pages.