---
title: "Ambitious Card — Street Routine"
tags: ["cards","sleights","audience-participation"]
summary: "A tight 4-minute version with double-lifts and a kicker ending."
published: 2025-09-01
---
Write-up goes here.