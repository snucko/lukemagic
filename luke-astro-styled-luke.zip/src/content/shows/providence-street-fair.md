---
title: "Providence Street Fair"
date: "2025-10-12"
time: "14:00"
city: "Providence, RI"
venue: "Atwells Ave Stage"
rsvpUrl: "https://example.com/rsvp"
---
Short blurb about the show.