---
title: "Welcome to Luke's site!"
summary: "A brand new site for Luke’s magic."
published: 2025-09-10
---
First post.